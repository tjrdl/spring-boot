package com.boot.boot_join_mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJoinMysqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
