package com.boot.boot_join_mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJoinMysqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(BootJoinMysqlApplication.class, args);
    }

}
