package com.boot.boot_join_mysql.Service;

import com.boot.boot_join_mysql.dto.EmpDeptDTO;

import java.util.ArrayList;
import java.util.HashMap;

public interface EmpInfoService {
	public ArrayList<EmpDeptDTO> list();
}
